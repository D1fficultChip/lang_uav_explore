#!/usr/bin/env python3
from __future__ import annotations
import argparse
import os
import time
import yaml

from central_runtime.plan_loader import load_plan
from central_runtime.infer_reader import InferJsonReader
from central_runtime.prompt_controller import PromptController
from central_runtime.executor import PlanExecutor
from central_runtime.adapters.falcon_search import FalconSearchAdapter
from central_runtime.adapters.track_hold import TrackHoldAdapter
from central_runtime.adapters.navigate_stub import NavigateStubAdapter

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True, help="path to plan.json")
    ap.add_argument("--config", required=True, help="path to config.yaml")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    shared_dir = cfg.get("shared_dir", "/shared")
    infer_json = os.path.join(shared_dir, cfg.get("infer_json", "infer.json"))
    prompt_txt = os.path.join(shared_dir, cfg.get("prompt_txt", "prompt.txt"))
    tick_hz = float(cfg.get("tick_hz", 10.0))
    log_path = cfg.get("log_jsonl_path", os.path.join(shared_dir, "plan_runtime.jsonl"))

    plan = load_plan(args.plan)

    infer_reader = InferJsonReader(infer_json)
    prompt_ctl = PromptController(prompt_txt)

    # Build adapters
    adapters = {}
    a_cfg = cfg.get("adapters", {}) or {}
    # SEARCH
    if "SEARCH" in a_cfg:
        cmd = a_cfg["SEARCH"].get("cmd")
        if cmd:
            adapters["SEARCH"] = FalconSearchAdapter(cmd=cmd)
    # TRACK
    adapters["TRACK"] = TrackHoldAdapter()
    # NAVIGATE
    adapters["NAVIGATE"] = NavigateStubAdapter()

    verified_cfg = cfg.get("verified", {}) or {}

    ex = PlanExecutor(
        plan=plan,
        infer_reader=infer_reader,
        prompt_ctl=prompt_ctl,
        adapters=adapters,
        tick_hz=tick_hz,
        log_jsonl_path=log_path,
        verified_cfg=verified_cfg,
    )
    ex.run()

if __name__ == "__main__":
    main()
